public class Fornecedor {

    String tipo;
    int quantidade;



}
